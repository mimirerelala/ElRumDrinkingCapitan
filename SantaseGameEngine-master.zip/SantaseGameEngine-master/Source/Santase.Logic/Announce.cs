﻿namespace Santase.Logic
{
    public enum Announce
    {
        None = 0,
        Twenty = 20,
        Forty = 40
    }
}
